# dips.fhir.retinaintegration#0.5.0: RetinaIntegration

## Pages

* [Home](index.md)
* [Artifacts Summary](artifacts.md)
* [Changelog](changelog.md)
* [Issues and Enhancements](Issues-and-Enhancements.md)

## Resources

### CodeSystems

* [Retina Cautions](CodeSystem-retina-caution-cs.md)
* [Retina Conclusion](CodeSystem-retina-conclusion-code-cs.md)
* [Retina Image Quality](CodeSystem-retina-image-quality-cs.md)
* [Retina Image View](CodeSystem-retina-image-view-cs.md)

### ValueSets

* [Retina Body Site](ValueSet-retina-body-site-vs.md)
* [Retina Cautions](ValueSet-retina-caution-vs.md)
* [Retina Conclusion](ValueSet-retina-conclusion-code-vs.md)
* [Retina Image Quality](ValueSet-retina-image-quality-vs.md)
* [Retina Image View](ValueSet-retina-image-view-vs.md)
* [Retina Imaging Procedures](ValueSet-retina-imaging-procedure-vs.md)

### Resource Profiles

* [Retina AI Device](StructureDefinition-retina-ai-device.md)
* [Retina Diabetic Macular Edema Finding](StructureDefinition-retina-diabetic-macular-edema-finding.md)
* [Retina Diabetic Retinopathy Finding](StructureDefinition-retina-diabetic-retinopathy-finding.md)
* [Retina DiagnosticReport](StructureDefinition-retina-diagnostic-report.md)
* [Retina HbA1c Observation](StructureDefinition-retina-hba1c-observation.md)
* [Retina Image Quality Assessment](StructureDefinition-retina-image-quality-asessment.md)
* [Retina ImagingStudy](StructureDefinition-retina-imagingstudy.md)
* [Retina Observation](StructureDefinition-retina-observation.md)

### Extensions

* [Cautions](StructureDefinition-cautions-extension.md)
* [Days Until Next Examination](StructureDefinition-days-until-next-examination-extension.md)
* [Previous Examination Conclusion](StructureDefinition-previous-examination-conclusion-extension.md)
* [Retinal Image View](StructureDefinition-retinal-image-view.md)

### CapabilityStatements

* [Retina CapabilityStatement](CapabilityStatement-RetinaCapabilityStatement.md)

### ImplementationGuides

* [RetinaIntegration](index.md)

### NamingSystems

* [RetinaDiagnosticReportIdentifierSystem](NamingSystem-retina-diagnostic-report-ns.md)
* [RetinaImagingStudyIdentifierSystem](NamingSystem-retina-imaging-study-ns.md)
* [RetinaObservationIdentifierSystem](NamingSystem-retina-observation-ns.md)

### OperationDefinitions

* [Retina Append AI Result Operation](OperationDefinition-append-retina-ai-result.md)

### Examples

* [Bundle-SingleExamination-Example (Bundle)](Bundle-Bundle-SingleExamination-Example.md)
* [Bundle-TwoExaminations-Example (Bundle)](Bundle-Bundle-TwoExaminations-Example.md)
* [RetinaAIDevice-Example (Device)](Device-RetinaAIDevice-Example.md)
* [RetinaCameraDevice-Example (Device)](Device-RetinaCameraDevice-Example.md)
* [RetinaDiagnosticReport-Example-PendingAI (DiagnosticReport)](DiagnosticReport-RetinaDiagnosticReport-Example-PendingAI.md)
* [RetinaDiagnosticReport-Example (DiagnosticReport)](DiagnosticReport-RetinaDiagnosticReport-Example.md)
* [bb2690e7-ca9f-4070-9c35-c7e36976b144 (DiagnosticReport)](DiagnosticReport-bb2690e7-ca9f-4070-9c35-c7e36976b144.md)
* [RetinaImagingStudy-available-Example (ImagingStudy)](ImagingStudy-RetinaImagingStudy-available-Example.md)
* [RetinaImagingStudy-registered-Example (ImagingStudy)](ImagingStudy-RetinaImagingStudy-registered-Example.md)
* [RetinaDiabeticMacularEdemaFinding-Example-left (Observation)](Observation-RetinaDiabeticMacularEdemaFinding-Example-left.md)
* [RetinaDiabeticMacularEdemaFinding-Example-right (Observation)](Observation-RetinaDiabeticMacularEdemaFinding-Example-right.md)
* [RetinaDiabeticRetinopathyFinding-Example-left (Observation)](Observation-RetinaDiabeticRetinopathyFinding-Example-left.md)
* [RetinaDiabeticRetinopathyFinding-Example-right (Observation)](Observation-RetinaDiabeticRetinopathyFinding-Example-right.md)
* [RetinaHbA1cObservation-Example (Observation)](Observation-RetinaHbA1cObservation-Example.md)
* [RetinaImageQualityAssessment-Example-left (Observation)](Observation-RetinaImageQualityAssessment-Example-left.md)
* [RetinaImageQualityAssessment-Example-right (Observation)](Observation-RetinaImageQualityAssessment-Example-right.md)
* [RetinaAppendAIResultOperation-Example (Parameters)](Parameters-RetinaAppendAIResultOperation-Example.md)
