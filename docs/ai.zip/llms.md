# dips.fhir.retinaintegration#0.1.3: RetinaIntegration

## Pages

* [Home](index.md)
* [Artifacts Summary](artifacts.md)

## Resources

### CodeSystems

* [Grading Conclusion](CodeSystem-retina-conclusioncode-cs.md)
* [Image Quality](CodeSystem-retina-imagequality-cs.md)
* [Next Examination](CodeSystem-tiltakstatus-nesteundersokelse-cs.md)
* [Grading Pending](CodeSystem-videre-forlop-cs.md)

### ValueSets

* [Grading Conclusion](ValueSet-retina-conclusioncode-vs.md)
* [Image Quality](ValueSet-retina-imagequality-vs.md)
* [Next Examination](ValueSet-tiltaksstatus-forrigeUndersokelse-vs.md)
* [Grading Pending](ValueSet-videre-forlop-vs.md)

### Resource Profiles

* [Retina DiagnosticReport](StructureDefinition-RetinaDiagnosticReport.md)
* [Retina Observation](StructureDefinition-RetinaObservation.md)
* [Diabetic Macular Edema Left Eye Observation](StructureDefinition-dme-left-eye-observation.md)
* [Diabetic Macular Edema Right Eye Observation](StructureDefinition-dme-right-eye-observation.md)
* [Diabetic Retinopathy Left Eye Observation](StructureDefinition-dr-left-eye-observation.md)
* [Diabetic Retinopathy Right Eye Observation](StructureDefinition-dr-right-eye-observation.md)
* [Fundus Photography Observation](StructureDefinition-fundus-foto-observation.md)
* [HbA1c Observation](StructureDefinition-hba1c-observation.md)
* [OCT Observation](StructureDefinition-oct-observation.md)

### Extensions

* [Deadline Next Examination](StructureDefinition-frist-nesteundersokelse-extension.md)
* [AI Product Name](StructureDefinition-ki-productname-extension.md)
* [AI Protocol](StructureDefinition-ki-protokoll-extension.md)
* [AI Algorithm Version](StructureDefinition-ki-versjon-algoritme-extension.md)
* [Image Quality](StructureDefinition-retina-imagequality-extension.md)
* [Next Examination Previous Examination](StructureDefinition-tiltaksstatus-forrige-undersokelse-extension.md)
* [Grading Pending](StructureDefinition-videre-forlop-extension.md)

### CapabilityStatements

* [DIPSRetinaCapabilityStatement](CapabilityStatement-DIPSRetinaCapabilityStatement.md)

### ImplementationGuides

* [RetinaIntegration](index.md)

### NamingSystems

* [RetinaExaminationIdentifierSystem](NamingSystem-retina-examination-id.md)
* [RetinaObservationIdentifierSystem](NamingSystem-retina-observation-id.md)

### OperationDefinitions

* [AppendRetinaAIResult](OperationDefinition-append-retina-ai-result.md)

### Examples

* [BundleWithSinglExamination-Example (Bundle)](Bundle-BundleWithSinglExamination-Example.md)
* [BundleWithSingleExaminationAndAI-Example (Bundle)](Bundle-BundleWithSingleExaminationAndAI-Example.md)
* [BundleWithTwoExaminations-Example (Bundle)](Bundle-BundleWithTwoExaminations-Example.md)
* [bb2690e7-ca9f-4070-9c35-c7e36976b144 (DiagnosticReport)](DiagnosticReport-bb2690e7-ca9f-4070-9c35-c7e36976b144.md)
* [AddAIResultOperation (Parameters)](Parameters-AddAIResultOperation.md)
* [cdp1123122 (Patient)](Patient-cdp1123122.md)
* [cdp1123123 (Patient)](Patient-cdp1123123.md)
