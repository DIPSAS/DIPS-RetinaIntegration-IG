# dips.fhir.retinaintegration#0.2.0: RetinaIntegration

## Pages

* [Home](index.md)
* [Artifacts Summary](artifacts.md)

## Resources

### CodeSystems

* [Retina Cautions](CodeSystem-retina-caution-cs.md)
* [Retina Conclusion](CodeSystem-retina-conclusioncode-cs.md)
* [Retina Image Quality](CodeSystem-retina-imagequality-cs.md)

### ValueSets

* [Retina Body Site](ValueSet-retina-body-site-vs.md)
* [Retina Conclusion](ValueSet-retina-conclusioncode-vs.md)
* [Retina Image Quality](ValueSet-retina-imagequality-vs.md)
* [Retina Imaging Procedures](ValueSet-retina-imaging-procedure-vs.md)
* [Retina Initial Instructions](ValueSet-retina-initial-instructions-vs.md)

### Resource Profiles

* [Retina AI Device](StructureDefinition-retina-ai-device.md)
* [Retina DiagnosticReport](StructureDefinition-retina-diagnostic-report.md)
* [Retina Eye Observation](StructureDefinition-retina-eye-observation.md)
* [Retina HbA1c Observation](StructureDefinition-retina-hba1c-observation.md)
* [Retina ImagingStudy](StructureDefinition-retina-imagingstudy.md)
* [Retina Observation](StructureDefinition-retina-observation.md)

### Extensions

* [Days Until Next Examination](StructureDefinition-days-until-next-examination-extension.md)
* [Initial Instructions](StructureDefinition-initial-instructions-extension.md)
* [Previous Examination Conclusion](StructureDefinition-previous-examination-conclusion-extension.md)

### CapabilityStatements

* [Retina CapabilityStatement](CapabilityStatement-RetinaCapabilityStatement.md)

### ImplementationGuides

* [RetinaIntegration](index.md)

### NamingSystems

* [RetinaExaminationIdentifierSystem](NamingSystem-retina-examination-id.md)
* [RetinaObservationIdentifierSystem](NamingSystem-retina-observation-id.md)

### OperationDefinitions

* [Retina Append AI Result Operation](OperationDefinition-append-retina-ai-result.md)

### Examples

* [Bundle-SinglExamination-Example (Bundle)](Bundle-Bundle-SinglExamination-Example.md)
* [Bundle-TwoExaminations-Example (Bundle)](Bundle-Bundle-TwoExaminations-Example.md)
* [RetinaAIDevice-Example (Device)](Device-RetinaAIDevice-Example.md)
* [RetinaAIDevice-input (Device)](Device-RetinaAIDevice-input.md)
* [RetinaCameraDevice-Example (Device)](Device-RetinaCameraDevice-Example.md)
* [RetinaDiagnosticReport-Example-PendingAI (DiagnosticReport)](DiagnosticReport-RetinaDiagnosticReport-Example-PendingAI.md)
* [RetinaDiagnosticReport-Example (DiagnosticReport)](DiagnosticReport-RetinaDiagnosticReport-Example.md)
* [bb2690e7-ca9f-4070-9c35-c7e36976b144 (DiagnosticReport)](DiagnosticReport-bb2690e7-ca9f-4070-9c35-c7e36976b144.md)
* [RetinaImagingStudy-available-Example (ImagingStudy)](ImagingStudy-RetinaImagingStudy-available-Example.md)
* [RetinaImagingStudy-registered-Example (ImagingStudy)](ImagingStudy-RetinaImagingStudy-registered-Example.md)
* [RetinaEyeObservation-Example-left (Observation)](Observation-RetinaEyeObservation-Example-left.md)
* [RetinaEyeObservation-Example-right (Observation)](Observation-RetinaEyeObservation-Example-right.md)
* [RetinaEyeObservation-input-left (Observation)](Observation-RetinaEyeObservation-input-left.md)
* [RetinaEyeObservation-input-right (Observation)](Observation-RetinaEyeObservation-input-right.md)
* [RetinaHbA1cObservation-Example (Observation)](Observation-RetinaHbA1cObservation-Example.md)
* [RetinaAppendAIResultOperation-Example (Parameters)](Parameters-RetinaAppendAIResultOperation-Example.md)
