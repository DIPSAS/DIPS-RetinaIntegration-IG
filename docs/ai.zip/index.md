# Home - RetinaIntegration v0.5.0

* [**Table of Contents**](toc.md)
* **Home**

## Home

| | |
| :--- | :--- |
| *Official URL*:http://dips.no/fhir/RetinaIntegration/ImplementationGuide/dips.fhir.retinaintegration | *Version*:0.5.0 |
| Draft as of 2025-12-18 | *Computable Name*:RetinaIntegration |

### RetinaIntegration API

RetinaIntegration is an API for integrating with the DIPS EyeCare-retinopathy application which is used in the retinopathy screening of diabetic patients.

The purpose of the API is to for an AI solution to discover examinations that is waiting for grading, get the details about those examinations, and report back any AI findings concerning those findings and what the next step should be.

### System Components and Interactions

The following diagram shows some of the components and their interactions. The regional system, the client, consists of a media archive, an integration platform with some business logic, and an AI system. For the purpose of this discussion we consider the AI system and the integration platform as one system.

The DIPS system consist of the EyeCare application and the Retina Integration API, among other things.

1. Photographer starts taking retina pictures.
1. The media archive sends a message to DIPS with the new SectraStudyId.
* A ImagingStudy is added to the report.
* The status of the imaging study will be `registered`
* The status of the diagnostic report will be `partial`

1. When image series is completed the AI system grades the images.
1. When photographer stores and approves the photographer form in EyeCare DIPS creates a DiagnosticReport for a new retina examination.
* The report status is `registered`
* If there is a SectraStudyId that matches the examination the status will be `partial`

1. AI system queries for DiagnosticReports that is pending grading:
* DiagnosticReport have ImagingStudy with status `registered`

1. AI system calls operation to append image information, findings and conclusions
* Imaging study will be `available`
* Diagnostic report status will be `partial` or `final` depending on the conclusion

1. Manual grader optionally examines the pictures reaches a conclusion
* The report status will be `partial`or `final` depending on conclusion

1. Secondary grader optionally examines the pictures
* The report status will be `partial`or `final` depending on conclusion

The numbers indicates one possible sequence of the signals and actions. There may be many variations of this sequences.

TODO: Handle appending of AI grading when the report is in final state, possible because it is already graded by a manual grader or that it was already graded by AI with another image study. Report will be in state `appended`.

![](component-diagram.svg)

### Retina DiagnosticReport Model

The diagnostic report goes through phases as the grading process progress. These phases are reflected in the `DiagnosticReport.status` field.

1. `registered`: The report exists but it does not contain any information about images. It may contain information about HbA1c.
1. `partial`: The report has information about`ImagingStudy`, one or more SectraStudyIDs are connected to the examination.
1. `preliminary`: AI system has added information an possible conclusions about an ImagingStudy but the grading process is not finished.
1. `final`: The grading process has reached a conclusion.

#### DiagnosticReport.status = registered

The report will be in `registered`state after the photographer has saved and approved the photographer form in EyeCare and before any imaging studies are connected to the examination.

Available information in the `registered` state is:

* hbA1cObservation result containing the blood sugar value reported by the patient.
* cautions extension : optional codes from the 5000-series (if any), e.g. 5001 "Patient does not want an AI based grading result."
* previousExaminationConclusion : conclusionCode from previous examination (if any), from the 1000 series.
* code : Type of imaging ordered, fundus photography and/or OCT from RetinaImagingProcedureValueSet.

![](diagnostic-report-registered.svg)

Many of the objects in the model will contain a subject identifier for the patient. Many objects will also have `partOf`references back to the diagnostic report. These references are for simplicity omitted from this overview.

#### DiagnosticReport.status = partial

When a Sectra imaging study is mapped to the examination a `ImagingStudy` is added to the report. The status of the ImagingStudy will be `registered` and the status of the diagnostic report will be `partial` meaning there is data available.

The diagnostic report may contain zero, one or several imaging studies.

One imaging study will contain one and exactly on sectraStudyId identifier.

![](diagnostic-report-partial.svg)

#### DiagnosticReport.status = preliminary | final

The AI system will add information about the images and a result of the AI grading of the pictures.

AI will add two image series to the imaging study, on for each eye. The ImagingSeries.bodySite will have snomed codes for retina left or right eye.

AI will add assessment of the image quality for each image in the study.

For each picture the AI will report the `view` which is macular centered or optical disc centered. This information originates in the camera system and is not assessed by the AI system. It is therefor not an observation or evaluation, but a property of the image.

The AI system will add evaluations (observations) about possible diabetic retinopathy finding and diabetic macular edema finding.

A DiagnosticReport after AI result is added.

![](diagnostic-report-with-ai.svg)

### Queries

##### Query for a specific examination identified by the ID

```
{baseurl}/DiagnosticReport?_profile=RetinaDiagnosticReport&_id=aaaaaaaa-bbbb-cccc-dddd-eeeeeeeeeeee&_include=DiagnosticReport:result

```

##### Query for getting examinations in a given time interval

```
{baseurl}/DiagnosticReport?_profile=RetinaDiagnosticReport&status=preliminary&date=ge2025-10-02&date=le2025-10-03&_include=DiagnosticReport:result

```

##### Find examinations waiting for AI grading (DiagnosticReports with registered imaging studies)

```
GET {baseUrl}/DiagnosticReport?_profile=RetinaDiagnosticReport&imagingStudy.status=registered&_include=DiagnosticReport:imaging-study

```

### Operations

##### Append AI result

Add ai result to an examination using the following operation:

```
{baseUrl}/DiagnosticReport/aaaaaaaa-bbbb-cccc-dddd-eeeeeeeeeeee/$append-retina-ai-result

```

The operation accepts multiple parameters including observation resources, AI metadata, imaging studies, and workflow tags.

For detailed parameter specifications, see the [AppendRetinaAIResult OperationDefinition](OperationDefinition-append-retina-ai-result.md).

