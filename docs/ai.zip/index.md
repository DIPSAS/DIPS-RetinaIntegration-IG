# Home - RetinaIntegration v0.2.0

* [**Table of Contents**](toc.md)
* **Home**

## Home

| | |
| :--- | :--- |
| *Official URL*:http://dips.no/fhir/RetinaIntegration/ImplementationGuide/dips.fhir.retinaintegration | *Version*:0.2.0 |
| Draft as of 2025-11-30 | *Computable Name*:RetinaIntegration |

## RetinaIntegration API

RetinaIntegration is an API for integrating with the DIPS EyeCare-retinopathy application which is used in the retinopathy screening of diabetic patients.

The purpose of the API is to for an AI solution to discover examinations that is waiting for grading, get the details about those examinations, and report back any AI findings concerning those findings and what the next step should be.

### Workflow Integration

1. DIPS creates a DiagnosticReport for a new retina examination
1. External AI system queries for DiagnosticReports pending grading
* DiagnosticReport.status = TODO
* DiagnosticReport have ImagingStudy with status = registered

1. AI system analyses the retinal images
1. AI system calls this operation to append results
1. DIPS updates the DiagnosticReport with the AI findings
* ImagingStudy will get status available
* DiagnosticReport.status will be partial or final depending on what the next step is.

### System Components

The following diagram shows the components and workflow of the RetinaIntegration system:

![](component-diagram.svg)

## Retina DiagnosticReport Model

A DiagnosticReport after AI result is added.

![](diagnostic-report-with-ai.svg)

### Queries

#### Query for a specific examination identified by the ID

```
{baseurl}/DiagnosticReport?_profile=RetinaDiagnosticReport&_id=aaaaaaaa-bbbb-cccc-dddd-eeeeeeeeeeee&_include=DiagnosticReport:result

```

#### Query for getting examinations in a given time interval

```
{baseurl}/DiagnosticReport?_profile=RetinaDiagnosticReport&status=preliminary&date=ge2025-10-02&date=le2025-10-03&_include=DiagnosticReport:result

```

#### Find examinations waiting for AI grading (DiagnosticReports with registered imaging studies)

```
GET {baseUrl}/DiagnosticReport?_profile=RetinaDiagnosticReport&imagingStudy.status=registered&_include=DiagnosticReport:imaging-study

```

### Operations

#### Append AI result

Add ai result to an examination using the following operation:

```
{baseUrl}/DiagnosticReport/aaaaaaaa-bbbb-cccc-dddd-eeeeeeeeeeee/$append-retina-ai-result

```

The operation accepts multiple parameters including observation resources, AI metadata, imaging studies, and workflow tags.

For detailed parameter specifications, see the [AppendRetinaAIResult OperationDefinition](OperationDefinition-append-retina-ai-result.md).

