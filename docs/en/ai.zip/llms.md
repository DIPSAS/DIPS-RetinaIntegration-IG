# dips.fhir.retinaintegration#0.9.1: RetinaIntegration(en)

## Pages

* [Home](index.md)
* [Artifacts Summary](artifacts.md)
* [Changelog](changelog.md)
* [](Issues-and-Enhancements.md)
* [Model](Model.md)
* [](StateTransitions.md)

## Resources

### CodeSystems

* [Retina AI Gradability Codes](CodeSystem-retina-ai-gradability-cs.md)
* [Retina Caution Codes](CodeSystem-retina-caution-cs.md)
* [Retina Conclusion Codes](CodeSystem-retina-conclusion-code-cs.md)
* [Retina Image Quality Codes](CodeSystem-retina-image-quality-cs.md)
* [Retina Image View Codes](CodeSystem-retina-image-view-cs.md)

### ValueSets

* [Retina AI Gradability](ValueSet-retina-ai-gradability-vs.md)
* [Retina AI Integration Conclusion](ValueSet-retina-append-ai-conclusion-vs.md)
* [Retina Body Site](ValueSet-retina-body-site-vs.md)
* [Retina Cautions](ValueSet-retina-caution-vs.md)
* [Retina Conclusion](ValueSet-retina-conclusion-code-vs.md)
* [Retina Image Parameter ValueSet](ValueSet-retina-image-parameter-vs.md)
* [Retina Image Quality](ValueSet-retina-image-quality-vs.md)
* [Retina Image View](ValueSet-retina-image-view-vs.md)
* [Retina Imaging Procedures](ValueSet-retina-imaging-procedure-vs.md)

### Resource Profiles

* [Retina AI Device](StructureDefinition-retina-ai-device.md)
* [Retina Camera Device](StructureDefinition-retina-camera-device.md)
* [Retina Diabetic Macular Edema Finding](StructureDefinition-retina-diabetic-macular-edema-finding.md)
* [Retina Diabetic Retinopathy Finding](StructureDefinition-retina-diabetic-retinopathy-finding.md)
* [Retina DiagnosticReport](StructureDefinition-retina-diagnostic-report.md)
* [Retina HbA1c Observation](StructureDefinition-retina-hba1c-observation.md)
* [Retina Image Parameter](StructureDefinition-retina-image-parameter.md)
* [Retina Image Quality Assessment](StructureDefinition-retina-image-quality-asessment.md)
* [Retina ImagingStudy](StructureDefinition-retina-imagingstudy.md)
* [Retina Observation](StructureDefinition-retina-observation.md)

### Extensions

* [Cautions](StructureDefinition-cautions-extension.md)
* [Days Until Next Examination](StructureDefinition-days-until-next-examination-extension.md)
* [Previous Examination Conclusion](StructureDefinition-previous-examination-conclusion-extension.md)
* [Retinal Image View](StructureDefinition-retinal-image-view.md)

### CapabilityStatements

* [Retina CapabilityStatement](CapabilityStatement-RetinaCapabilityStatement.md)

### ImplementationGuides

* [RetinaIntegration](ImplementationGuide-dips.fhir.retinaintegration.md)

### NamingSystems

* [RetinaDiagnosticReportIdentifierSystem](NamingSystem-retina-diagnostic-report-ns.md)
* [RetinaImagingStudyIdentifierSystem](NamingSystem-retina-imaging-study-ns.md)
* [RetinaObservationIdentifierSystem](NamingSystem-retina-observation-ns.md)

### OperationDefinitions

* [Retina Append AI Result Operation](OperationDefinition-append-retina-ai-result.md)
* [Query By Date Operation](OperationDefinition-retina-by-date.md)

### Examples

* [Bundle-SingleExamination-Example (Bundle)](Bundle-Bundle-SingleExamination-Example.md)
* [Bundle-TwoExaminations-Example (Bundle)](Bundle-Bundle-TwoExaminations-Example.md)
* [RetinaAIDevice-Example (Device)](Device-RetinaAIDevice-Example.md)
* [RetinaCameraDevice-Example (Device)](Device-RetinaCameraDevice-Example.md)
* [RetinaDiagnosticReport-Example-PendingAI (DiagnosticReport)](DiagnosticReport-RetinaDiagnosticReport-Example-PendingAI.md)
* [RetinaDiagnosticReport-Example (DiagnosticReport)](DiagnosticReport-RetinaDiagnosticReport-Example.md)
* [bb2690e7-ca9f-4070-9c35-c7e36976b144 (DiagnosticReport)](DiagnosticReport-bb2690e7-ca9f-4070-9c35-c7e36976b144.md)
* [RetinaImagingStudy-available-Example (ImagingStudy)](ImagingStudy-RetinaImagingStudy-available-Example.md)
* [RetinaImagingStudy-registered-Example (ImagingStudy)](ImagingStudy-RetinaImagingStudy-registered-Example.md)
* [RetinaDiabeticMacularEdemaFinding-Example-left (Observation)](Observation-RetinaDiabeticMacularEdemaFinding-Example-left.md)
* [RetinaDiabeticMacularEdemaFinding-Example-right (Observation)](Observation-RetinaDiabeticMacularEdemaFinding-Example-right.md)
* [RetinaDiabeticRetinopathyFinding-Example-left (Observation)](Observation-RetinaDiabeticRetinopathyFinding-Example-left.md)
* [RetinaDiabeticRetinopathyFinding-Example-right (Observation)](Observation-RetinaDiabeticRetinopathyFinding-Example-right.md)
* [RetinaHbA1cObservation-Example (Observation)](Observation-RetinaHbA1cObservation-Example.md)
* [RetinaImageParameter-Example (Observation)](Observation-RetinaImageParameter-Example.md)
* [RetinaImageQualityAssessment-Example-left (Observation)](Observation-RetinaImageQualityAssessment-Example-left.md)
* [RetinaImageQualityAssessment-Example-right (Observation)](Observation-RetinaImageQualityAssessment-Example-right.md)
* [RetinaAppendAIResultOperation-Example (Parameters)](Parameters-RetinaAppendAIResultOperation-Example.md)
* [RetinaQueryByDate-Example (Parameters)](Parameters-RetinaQueryByDate-Example.md)
