# Bundle-TwoExaminations-Example - RetinaIntegration v0.6.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Bundle-TwoExaminations-Example**

## Example Bundle: Bundle-TwoExaminations-Example



## Resource Content

```json
{
  "resourceType" : "Bundle",
  "id" : "Bundle-TwoExaminations-Example",
  "type" : "searchset",
  "total" : 7,
  "entry" : [
    {
      "resource" : {
        "resourceType" : "DiagnosticReport",
        "id" : "RetinaDiagnosticReport-1",
        "meta" : {
          "profile" : [
            "http://dips.no/fhir/RetinaIntegration/StructureDefinition/retina-diagnostic-report"
          ]
        },
        "text" : {
          "status" : "generated",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"DiagnosticReport_RetinaDiagnosticReport-1\"> </a><p class=\"res-header-id\"><b>Generated Narrative: DiagnosticReport RetinaDiagnosticReport-1</b></p><a name=\"RetinaDiagnosticReport-1\"> </a><a name=\"hcRetinaDiagnosticReport-1\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"StructureDefinition-retina-diagnostic-report.html\">Retina DiagnosticReport</a></p></div><h2><span title=\"Codes:{http://ehelse.no/fhir/CodeSystem/no-kodeverk-7275 CKDP10}\">Fundusfotografi</span> </h2><table class=\"grid\"><tr><td>Subject</td><td>Unable to get Patient Details</td></tr><tr><td>Identifier</td><td> <a href=\"NamingSystem-retina-diagnostic-report-ns.html\" title=\"A naming system for identifying Retina DiagnosticReports using GUIDs. An examination ID is used to uniquely identify the single Retina DiagnosticReport for that examination.\">RetinaDiagnosticReportIdentifierSystem</a>/550e8400-e29b-41d4-a716-446655440000</td></tr></table><p><b>Report Details</b></p><table class=\"grid\"><tr><td><b>Code</b></td><td><b>Value</b></td><td><b>Flags</b></td><td><b>When For</b></td></tr><tr><td><a href=\"Bundle-Bundle-SingleExamination-Example.html#Observation_HbA1cObservation-1\"><span title=\"Codes:{http://snomed.info/sct 167491000202108}\">HbA1c</span></a></td><td>63.2</td><td>Final</td><td>2025-11-29 10:30:00+0000</td></tr></table><p><b>Coded Conclusions:</b></p><ul><li><span title=\"Codes:{http://dips.no/fhir/RetinaIntegration/CodeSystem/retina-conclusion-code-cs 1001}\">KI-gradering (basert på nåværende bilder)</span></li></ul></div>"
        },
        "identifier" : [
          {
            "system" : "http://dips.no/fhir/RetinaIntegration/examination-id",
            "value" : "550e8400-e29b-41d4-a716-446655440000"
          }
        ],
        "status" : "partial",
        "code" : {
          "coding" : [
            {
              "system" : "http://ehelse.no/fhir/CodeSystem/no-kodeverk-7275",
              "code" : "CKDP10",
              "display" : "Fundusfotografi"
            }
          ]
        },
        "subject" : {
          "reference" : "Patient/cdp1000807",
          "identifier" : {
            "system" : "urn:oid:2.16.578.1.12.4.1.4.1",
            "value" : "01015549145"
          }
        },
        "result" : [
          {
            "reference" : "Observation/HbA1cObservation-1"
          }
        ],
        "imagingStudy" : [
          {
            "reference" : "ImagingStudy/RegisteredImagingStudy-1"
          }
        ],
        "conclusionCode" : [
          {
            "coding" : [
              {
                "system" : "http://dips.no/fhir/RetinaIntegration/CodeSystem/retina-conclusion-code-cs",
                "code" : "1001",
                "display" : "KI-gradering (basert på nåværende bilder)"
              }
            ]
          }
        ]
      },
      "search" : {
        "mode" : "match"
      }
    },
    {
      "resource" : {
        "resourceType" : "Observation",
        "id" : "HbA1cObservation-1",
        "meta" : {
          "profile" : [
            "http://dips.no/fhir/RetinaIntegration/StructureDefinition/retina-hba1c-observation"
          ]
        },
        "text" : {
          "status" : "generated",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Observation_HbA1cObservation-1\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Observation HbA1cObservation-1</b></p><a name=\"HbA1cObservation-1\"> </a><a name=\"hcHbA1cObservation-1\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"StructureDefinition-retina-hba1c-observation.html\">Retina HbA1c Observation</a></p></div><p><b>identifier</b>: <a href=\"NamingSystem-retina-observation-ns.html\" title=\"A naming system for observation identifiers in RetinaIntegration using GUIDs.\">RetinaObservationIdentifierSystem</a>/a1b2c3d4-e5f6-47g8-h9i0-j1k2l3m4n5o6</p><p><b>status</b>: Final</p><p><b>code</b>: <span title=\"Codes:{http://snomed.info/sct 167491000202108}\">HbA1c</span></p><p><b>subject</b>: <a href=\"Patient/cdp1000807\">Patient/cdp1000807</a></p><p><b>effective</b>: 2025-11-29 10:30:00+0000</p><p><b>value</b>: 63.2</p></div>"
        },
        "identifier" : [
          {
            "system" : "http://dips.no/fhir/RetinaIntegration/observation-id",
            "value" : "a1b2c3d4-e5f6-47g8-h9i0-j1k2l3m4n5o6"
          }
        ],
        "status" : "final",
        "code" : {
          "coding" : [
            {
              "system" : "http://snomed.info/sct",
              "code" : "167491000202108",
              "display" : "HbA1c"
            }
          ]
        },
        "subject" : {
          "reference" : "Patient/cdp1000807",
          "identifier" : {
            "system" : "urn:oid:2.16.578.1.12.4.1.4.1",
            "value" : "01015549145"
          }
        },
        "effectiveDateTime" : "2025-11-29T10:30:00Z",
        "valueQuantity" : {
          "value" : 63.2
        }
      },
      "search" : {
        "mode" : "include"
      }
    },
    {
      "resource" : {
        "resourceType" : "ImagingStudy",
        "id" : "RegisteredImagingStudy-1",
        "meta" : {
          "profile" : [
            "http://dips.no/fhir/RetinaIntegration/StructureDefinition/retina-imagingstudy"
          ]
        },
        "text" : {
          "status" : "generated",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"ImagingStudy_RegisteredImagingStudy-1\"> </a><p class=\"res-header-id\"><b>Generated Narrative: ImagingStudy RegisteredImagingStudy-1</b></p><a name=\"RegisteredImagingStudy-1\"> </a><a name=\"hcRegisteredImagingStudy-1\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"StructureDefinition-retina-imagingstudy.html\">Retina ImagingStudy</a></p></div><p><b>identifier</b>: <a href=\"NamingSystem-retina-imaging-study-ns.html\" title=\"A naming system for imaging study identifiers in RetinaIntegration using GUIDs for internally and external Sectra image studies.\">RetinaImagingStudyIdentifierSystem</a>/MMA94126111</p><p><b>status</b>: Registered</p><p><b>subject</b>: <a href=\"Patient/cdp1000807\">Patient/cdp1000807</a></p></div>"
        },
        "identifier" : [
          {
            "system" : "http://dips.no/fhir/RetinaIntegration/sectra-image-study-id",
            "value" : "MMA94126111"
          }
        ],
        "status" : "registered",
        "subject" : {
          "reference" : "Patient/cdp1000807",
          "identifier" : {
            "system" : "urn:oid:2.16.578.1.12.4.1.4.1",
            "value" : "01015549145"
          }
        }
      },
      "search" : {
        "mode" : "include"
      }
    },
    {
      "resource" : {
        "resourceType" : "DiagnosticReport",
        "id" : "RetinaDiagnosticReport-2",
        "meta" : {
          "profile" : [
            "http://dips.no/fhir/RetinaIntegration/StructureDefinition/retina-diagnostic-report"
          ]
        },
        "text" : {
          "status" : "generated",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"DiagnosticReport_RetinaDiagnosticReport-2\"> </a><p class=\"res-header-id\"><b>Generated Narrative: DiagnosticReport RetinaDiagnosticReport-2</b></p><a name=\"RetinaDiagnosticReport-2\"> </a><a name=\"hcRetinaDiagnosticReport-2\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"StructureDefinition-retina-diagnostic-report.html\">Retina DiagnosticReport</a></p></div><h2><span title=\"Codes:{http://ehelse.no/fhir/CodeSystem/no-kodeverk-7275 CKDP10}\">Fundusfotografi</span> </h2><table class=\"grid\"><tr><td>Subject</td><td>Unable to get Patient Details</td></tr><tr><td>Identifier</td><td> <a href=\"NamingSystem-retina-diagnostic-report-ns.html\" title=\"A naming system for identifying Retina DiagnosticReports using GUIDs. An examination ID is used to uniquely identify the single Retina DiagnosticReport for that examination.\">RetinaDiagnosticReportIdentifierSystem</a>/9bee5eee-b15d-46b5-913e-d163833d7acd</td></tr></table><p><b>Report Details</b></p><table class=\"grid\"><tr><td><b>Code</b></td><td><b>Value</b></td><td><b>Flags</b></td><td><b>When For</b></td></tr><tr><td><a href=\"Bundle-Bundle-TwoExaminations-Example.html#Observation_RetinaHbA1cObservation-2\"><span title=\"Codes:{http://snomed.info/sct 167491000202108}\">HbA1c</span></a></td><td>63.2</td><td>Final</td><td>2025-06-06 10:30:00+0000</td></tr></table></div>"
        },
        "extension" : [
          {
            "url" : "http://dips.no/fhir/RetinaIntegration/StructureDefinition/previous-examination-conclusion-extension",
            "valueCoding" : {
              "system" : "http://dips.no/fhir/RetinaIntegration/CodeSystem/retina-conclusion-code-cs",
              "code" : "1004",
              "display" : "Ny fotokontroll (primærgradering)"
            }
          },
          {
            "url" : "http://dips.no/fhir/RetinaIntegration/StructureDefinition/cautions-extension",
            "valueCodeableConcept" : {
              "coding" : [
                {
                  "system" : "http://dips.no/fhir/RetinaIntegration/CodeSystem/retina-caution-cs",
                  "code" : "5001",
                  "display" : "Ønsker ikke KI-svar"
                }
              ]
            }
          }
        ],
        "identifier" : [
          {
            "system" : "http://dips.no/fhir/RetinaIntegration/examination-id",
            "value" : "9bee5eee-b15d-46b5-913e-d163833d7acd"
          }
        ],
        "status" : "partial",
        "code" : {
          "coding" : [
            {
              "system" : "http://ehelse.no/fhir/CodeSystem/no-kodeverk-7275",
              "code" : "CKDP10",
              "display" : "Fundusfotografi"
            }
          ]
        },
        "subject" : {
          "reference" : "Patient/cdp1000822",
          "identifier" : {
            "system" : "urn:oid:2.16.578.1.12.4.1.4.1",
            "value" : "02025649144"
          }
        },
        "result" : [
          {
            "reference" : "Observation/RetinaHbA1cObservation-2"
          }
        ],
        "imagingStudy" : [
          {
            "reference" : "ImagingStudy/RetinaImagingStudy-2-1"
          },
          {
            "reference" : "ImagingStudy/RetinaImagingStudy-2-2"
          }
        ]
      },
      "search" : {
        "mode" : "match"
      }
    },
    {
      "resource" : {
        "resourceType" : "Observation",
        "id" : "RetinaHbA1cObservation-2",
        "meta" : {
          "profile" : [
            "http://dips.no/fhir/RetinaIntegration/StructureDefinition/retina-hba1c-observation"
          ]
        },
        "text" : {
          "status" : "generated",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Observation_RetinaHbA1cObservation-2\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Observation RetinaHbA1cObservation-2</b></p><a name=\"RetinaHbA1cObservation-2\"> </a><a name=\"hcRetinaHbA1cObservation-2\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"StructureDefinition-retina-hba1c-observation.html\">Retina HbA1c Observation</a></p></div><p><b>identifier</b>: <a href=\"NamingSystem-retina-observation-ns.html\" title=\"A naming system for observation identifiers in RetinaIntegration using GUIDs.\">RetinaObservationIdentifierSystem</a>/718af0c2-794c-4bb0-96f9-365af89b0c08</p><p><b>status</b>: Final</p><p><b>code</b>: <span title=\"Codes:{http://snomed.info/sct 167491000202108}\">HbA1c</span></p><p><b>subject</b>: <a href=\"Patient/cdp1000822\">Patient/cdp1000822</a></p><p><b>effective</b>: 2025-06-06 10:30:00+0000</p><p><b>value</b>: 63.2</p></div>"
        },
        "identifier" : [
          {
            "system" : "http://dips.no/fhir/RetinaIntegration/observation-id",
            "value" : "718af0c2-794c-4bb0-96f9-365af89b0c08"
          }
        ],
        "status" : "final",
        "code" : {
          "coding" : [
            {
              "system" : "http://snomed.info/sct",
              "code" : "167491000202108",
              "display" : "HbA1c"
            }
          ]
        },
        "subject" : {
          "reference" : "Patient/cdp1000822",
          "identifier" : {
            "system" : "urn:oid:2.16.578.1.12.4.1.4.1",
            "value" : "02025649144"
          }
        },
        "effectiveDateTime" : "2025-06-06T10:30:00Z",
        "valueQuantity" : {
          "value" : 63.2
        }
      },
      "search" : {
        "mode" : "include"
      }
    },
    {
      "resource" : {
        "resourceType" : "ImagingStudy",
        "id" : "RetinaImagingStudy-2-1",
        "meta" : {
          "profile" : [
            "http://dips.no/fhir/RetinaIntegration/StructureDefinition/retina-imagingstudy"
          ]
        },
        "text" : {
          "status" : "generated",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"ImagingStudy_RetinaImagingStudy-2-1\"> </a><p class=\"res-header-id\"><b>Generated Narrative: ImagingStudy RetinaImagingStudy-2-1</b></p><a name=\"RetinaImagingStudy-2-1\"> </a><a name=\"hcRetinaImagingStudy-2-1\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"StructureDefinition-retina-imagingstudy.html\">Retina ImagingStudy</a></p></div><p><b>identifier</b>: <a href=\"NamingSystem-retina-imaging-study-ns.html\" title=\"A naming system for imaging study identifiers in RetinaIntegration using GUIDs for internally and external Sectra image studies.\">RetinaImagingStudyIdentifierSystem</a>/MMA94126081</p><p><b>status</b>: Registered</p><p><b>subject</b>: <a href=\"Patient/cdp1000822\">Patient/cdp1000822</a></p><p><b>procedureCode</b>: <span title=\"Codes:{http://ehelse.no/fhir/CodeSystem/no-kodeverk-7275 CKDP10}\">Fundusfotografi</span></p></div>"
        },
        "identifier" : [
          {
            "system" : "http://dips.no/fhir/RetinaIntegration/sectra-image-study-id",
            "value" : "MMA94126081"
          }
        ],
        "status" : "registered",
        "subject" : {
          "reference" : "Patient/cdp1000822",
          "identifier" : {
            "system" : "urn:oid:2.16.578.1.12.4.1.4.1",
            "value" : "02025649144"
          }
        },
        "procedureCode" : [
          {
            "coding" : [
              {
                "system" : "http://ehelse.no/fhir/CodeSystem/no-kodeverk-7275",
                "code" : "CKDP10",
                "display" : "Fundusfotografi"
              }
            ]
          }
        ]
      },
      "search" : {
        "mode" : "include"
      }
    },
    {
      "resource" : {
        "resourceType" : "ImagingStudy",
        "id" : "RetinaImagingStudy-2-2",
        "meta" : {
          "profile" : [
            "http://dips.no/fhir/RetinaIntegration/StructureDefinition/retina-imagingstudy"
          ]
        },
        "text" : {
          "status" : "generated",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"ImagingStudy_RetinaImagingStudy-2-2\"> </a><p class=\"res-header-id\"><b>Generated Narrative: ImagingStudy RetinaImagingStudy-2-2</b></p><a name=\"RetinaImagingStudy-2-2\"> </a><a name=\"hcRetinaImagingStudy-2-2\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"StructureDefinition-retina-imagingstudy.html\">Retina ImagingStudy</a></p></div><p><b>identifier</b>: <a href=\"NamingSystem-retina-imaging-study-ns.html\" title=\"A naming system for imaging study identifiers in RetinaIntegration using GUIDs for internally and external Sectra image studies.\">RetinaImagingStudyIdentifierSystem</a>/MMA94124928</p><p><b>status</b>: Registered</p><p><b>subject</b>: <a href=\"Patient/cdp1000822\">Patient/cdp1000822</a></p><p><b>procedureCode</b>: <span title=\"Codes:{http://ehelse.no/fhir/CodeSystem/no-kodeverk-7275 CKDP10}\">Fundusfotografi</span></p></div>"
        },
        "identifier" : [
          {
            "system" : "http://dips.no/fhir/RetinaIntegration/sectra-image-study-id",
            "value" : "MMA94124928"
          }
        ],
        "status" : "registered",
        "subject" : {
          "reference" : "Patient/cdp1000822",
          "identifier" : {
            "system" : "urn:oid:2.16.578.1.12.4.1.4.1",
            "value" : "02025649144"
          }
        },
        "procedureCode" : [
          {
            "coding" : [
              {
                "system" : "http://ehelse.no/fhir/CodeSystem/no-kodeverk-7275",
                "code" : "CKDP10",
                "display" : "Fundusfotografi"
              }
            ]
          }
        ]
      },
      "search" : {
        "mode" : "include"
      }
    }
  ]
}

```
