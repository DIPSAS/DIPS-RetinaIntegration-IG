# RetinaQueryByDate-Example - RetinaIntegration v0.8.1

## Example Parameters: RetinaQueryByDate-Example



## Resource Content

```json
{
  "resourceType" : "Parameters",
  "id" : "RetinaQueryByDate-Example",
  "parameter" : [{
    "name" : "start",
    "valueDateTime" : "2026-01-21T00:00:00Z"
  },
  {
    "name" : "end",
    "valueDateTime" : "2026-01-22T00:00:00Z"
  },
  {
    "name" : "pendingAI",
    "valueBoolean" : true
  }]
}

```
