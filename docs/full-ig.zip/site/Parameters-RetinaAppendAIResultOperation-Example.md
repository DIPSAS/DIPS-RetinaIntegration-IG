# RetinaAppendAIResultOperation-Example - RetinaIntegration v0.5.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **RetinaAppendAIResultOperation-Example**

## Example Parameters: RetinaAppendAIResultOperation-Example



## Resource Content

```json
{
  "resourceType" : "Parameters",
  "id" : "RetinaAppendAIResultOperation-Example",
  "parameter" : [
    {
      "name" : "sectraStudyId",
      "valueIdentifier" : {
        "system" : "http://dips.no/fhir/RetinaIntegration/sectra-image-study-id",
        "value" : "MMA94126079"
      }
    },
    {
      "name" : "conclusion",
      "valueCodeableConcept" : {
        "coding" : [
          {
            "system" : "http://dips.no/fhir/RetinaIntegration/CodeSystem/retina-conclusion-code-cs",
            "code" : "1004",
            "display" : "Ny fotokontroll (primærgradering)"
          }
        ]
      }
    },
    {
      "name" : "daysUntilNextExamination",
      "valueInteger" : 180
    },
    {
      "name" : "aiDevice",
      "resource" : {
        "resourceType" : "Device",
        "id" : "RetinaAIDevice-input",
        "meta" : {
          "profile" : [
            "http://dips.no/fhir/RetinaIntegration/StructureDefinition/retina-ai-device"
          ]
        },
        "deviceName" : [
          {
            "name" : "AwesomeAI for Retina",
            "type" : "model-name"
          }
        ],
        "version" : [
          {
            "type" : {
              "coding" : [
                {
                  "code" : "model-number"
                }
              ]
            },
            "value" : "v2.1.0"
          },
          {
            "type" : {
              "coding" : [
                {
                  "code" : "software"
                }
              ]
            },
            "value" : "Standard protocol"
          }
        ]
      }
    },
    {
      "name" : "rightDiabeticRetinopathyFinding",
      "resource" : {
        "resourceType" : "Observation",
        "id" : "RetinaDiabeticRetinopathyFinding-Example-right-input",
        "meta" : {
          "profile" : [
            "http://dips.no/fhir/RetinaIntegration/StructureDefinition/retina-diabetic-retinopathy-finding"
          ]
        },
        "status" : "final",
        "code" : {
          "coding" : [
            {
              "system" : "http://snomed.info/sct",
              "code" : "4855003",
              "display" : "Diabetic retinopathy"
            }
          ]
        },
        "effectiveDateTime" : "2025-09-30T12:00:00Z",
        "valueQuantity" : {
          "value" : 2
        },
        "bodySite" : {
          "coding" : [
            {
              "system" : "http://snomed.info/sct",
              "code" : "5597008",
              "display" : "Retina of right eye"
            }
          ]
        }
      }
    },
    {
      "name" : "rightDiabeticMacularEdemaFinding",
      "resource" : {
        "resourceType" : "Observation",
        "id" : "RetinaDiabeticMacularEdemaFinding-Example-right-input",
        "meta" : {
          "profile" : [
            "http://dips.no/fhir/RetinaIntegration/StructureDefinition/retina-diabetic-macular-edema-finding"
          ]
        },
        "status" : "final",
        "code" : {
          "coding" : [
            {
              "system" : "http://snomed.info/sct",
              "code" : "312912001",
              "display" : "Diabetic macular edema"
            }
          ]
        },
        "effectiveDateTime" : "2025-09-30T12:00:00Z",
        "valueBoolean" : false,
        "bodySite" : {
          "coding" : [
            {
              "system" : "http://snomed.info/sct",
              "code" : "5597008",
              "display" : "Retina of right eye"
            }
          ]
        }
      }
    },
    {
      "name" : "rightImageQualityAssessment",
      "resource" : {
        "resourceType" : "Observation",
        "id" : "RetinaImageQualityAssessment-Example-right-input",
        "meta" : {
          "profile" : [
            "http://dips.no/fhir/RetinaIntegration/StructureDefinition/retina-image-quality-asessment"
          ]
        },
        "status" : "final",
        "code" : {
          "coding" : [
            {
              "system" : "http://snomed.info/sct",
              "code" : "133887000",
              "display" : "Computer assisted image analysis for image quality"
            }
          ]
        },
        "effectiveDateTime" : "2025-09-30T12:00:00Z",
        "valueCodeableConcept" : {
          "coding" : [
            {
              "system" : "http://dips.no/fhir/RetinaIntegration/CodeSystem/retina-image-quality-cs",
              "code" : "2001",
              "display" : "Good"
            }
          ]
        },
        "bodySite" : {
          "coding" : [
            {
              "system" : "http://snomed.info/sct",
              "code" : "5597008",
              "display" : "Retina of right eye"
            }
          ]
        }
      }
    },
    {
      "name" : "leftDiabeticRetinopathyFinding",
      "resource" : {
        "resourceType" : "Observation",
        "id" : "RetinaDiabeticRetinopathyFinding-Example-left-input",
        "meta" : {
          "profile" : [
            "http://dips.no/fhir/RetinaIntegration/StructureDefinition/retina-diabetic-retinopathy-finding"
          ]
        },
        "status" : "final",
        "code" : {
          "coding" : [
            {
              "system" : "http://snomed.info/sct",
              "code" : "4855003",
              "display" : "Diabetic retinopathy"
            }
          ]
        },
        "effectiveDateTime" : "2025-09-30T12:00:00Z",
        "valueQuantity" : {
          "value" : 1
        },
        "bodySite" : {
          "coding" : [
            {
              "system" : "http://snomed.info/sct",
              "code" : "58443009",
              "display" : "Retina of left eye"
            }
          ]
        }
      }
    },
    {
      "name" : "leftDiabeticMacularEdemaFinding",
      "resource" : {
        "resourceType" : "Observation",
        "id" : "RetinaDiabeticMacularEdemaFinding-Example-left-input",
        "meta" : {
          "profile" : [
            "http://dips.no/fhir/RetinaIntegration/StructureDefinition/retina-diabetic-macular-edema-finding"
          ]
        },
        "status" : "final",
        "code" : {
          "coding" : [
            {
              "system" : "http://snomed.info/sct",
              "code" : "312912001",
              "display" : "Diabetic macular edema"
            }
          ]
        },
        "effectiveDateTime" : "2025-09-30T12:00:00Z",
        "valueBoolean" : true,
        "bodySite" : {
          "coding" : [
            {
              "system" : "http://snomed.info/sct",
              "code" : "58443009",
              "display" : "Retina of left eye"
            }
          ]
        }
      }
    },
    {
      "name" : "leftImageQualityAssessment",
      "resource" : {
        "resourceType" : "Observation",
        "id" : "RetinaImageQualityAssessment-Example-left-input",
        "meta" : {
          "profile" : [
            "http://dips.no/fhir/RetinaIntegration/StructureDefinition/retina-image-quality-asessment"
          ]
        },
        "status" : "final",
        "code" : {
          "coding" : [
            {
              "system" : "http://snomed.info/sct",
              "code" : "133887000",
              "display" : "Computer assisted image analysis for image quality"
            }
          ]
        },
        "effectiveDateTime" : "2025-09-30T12:00:00Z",
        "valueCodeableConcept" : {
          "coding" : [
            {
              "system" : "http://dips.no/fhir/RetinaIntegration/CodeSystem/retina-image-quality-cs",
              "code" : "2002",
              "display" : "Barely gradable"
            }
          ]
        },
        "bodySite" : {
          "coding" : [
            {
              "system" : "http://snomed.info/sct",
              "code" : "58443009",
              "display" : "Retina of left eye"
            }
          ]
        }
      }
    },
    {
      "name" : "fullReport",
      "valueAttachment" : {
        "contentType" : "text/plain",
        "data" : "Base64binary",
        "title" : "Full report"
      }
    },
    {
      "name" : "metaTags",
      "valueCoding" : {
        "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
        "code" : "VALIDATION",
        "display" : "validation review"
      }
    }
  ]
}

```
