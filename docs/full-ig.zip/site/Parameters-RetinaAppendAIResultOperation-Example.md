# RetinaAppendAIResultOperation-Example - RetinaIntegration v0.6.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **RetinaAppendAIResultOperation-Example**

## Example Parameters: RetinaAppendAIResultOperation-Example



## Resource Content

```json
{
  "resourceType" : "Parameters",
  "id" : "RetinaAppendAIResultOperation-Example",
  "parameter" : [
    {
      "name" : "sectraStudyId",
      "valueString" : "MMA94126079"
    },
    {
      "name" : "conclusion",
      "valueCodeableConcept" : {
        "coding" : [
          {
            "system" : "http://dips.no/fhir/RetinaIntegration/CodeSystem/retina-conclusion-code-cs",
            "code" : "1004",
            "display" : "Ny fotokontroll (primærgradering)"
          }
        ]
      }
    },
    {
      "name" : "daysUntilNextExamination",
      "valueInteger" : 180
    },
    {
      "name" : "rightDiabeticRetinopathy",
      "valueDecimal" : 0
    },
    {
      "name" : "rightDiabeticMacularEdema",
      "valueBoolean" : false
    },
    {
      "name" : "leftDiabeticRetinopathy",
      "valueDecimal" : 1
    },
    {
      "name" : "leftDiabeticMacularEdema",
      "valueBoolean" : false
    },
    {
      "name" : "rightEyeImage",
      "resource" : {
        "resourceType" : "Observation",
        "id" : "RetinaImageParameter-Example-right-input-1",
        "status" : "final",
        "code" : {
          "coding" : [
            {
              "system" : "http://dips.no/fhir/RetinaIntegration/CodeSystem/retina-image-view-cs",
              "code" : "6001",
              "display" : "Macula centered"
            },
            {
              "system" : "http://dips.no/fhir/RetinaIntegration/CodeSystem/retina-image-quality-cs",
              "code" : "2001",
              "display" : "Good"
            }
          ]
        }
      }
    },
    {
      "name" : "rightEyeImage",
      "resource" : {
        "resourceType" : "Observation",
        "id" : "RetinaImageParameter-Example-right-input-2",
        "status" : "final",
        "code" : {
          "coding" : [
            {
              "system" : "http://dips.no/fhir/RetinaIntegration/CodeSystem/retina-image-view-cs",
              "code" : "6002",
              "display" : "Optic disc centered"
            },
            {
              "system" : "http://dips.no/fhir/RetinaIntegration/CodeSystem/retina-image-quality-cs",
              "code" : "2002",
              "display" : "Barely gradable"
            }
          ]
        }
      }
    },
    {
      "name" : "leftEyeImage",
      "resource" : {
        "resourceType" : "Observation",
        "id" : "RetinaImageParameter-Example-left-input-1",
        "status" : "final",
        "code" : {
          "coding" : [
            {
              "system" : "http://dips.no/fhir/RetinaIntegration/CodeSystem/retina-image-view-cs",
              "code" : "6001",
              "display" : "Macula centered"
            },
            {
              "system" : "http://dips.no/fhir/RetinaIntegration/CodeSystem/retina-image-quality-cs",
              "code" : "2003",
              "display" : "Not gradable"
            }
          ]
        }
      }
    },
    {
      "name" : "leftEyeImage",
      "resource" : {
        "resourceType" : "Observation",
        "id" : "RetinaImageParameter-Example-left-input-2",
        "status" : "final",
        "code" : {
          "coding" : [
            {
              "system" : "http://dips.no/fhir/RetinaIntegration/CodeSystem/retina-image-view-cs",
              "code" : "6002",
              "display" : "Optic disc centered"
            },
            {
              "system" : "http://dips.no/fhir/RetinaIntegration/CodeSystem/retina-image-quality-cs",
              "code" : "2004",
              "display" : "Missing"
            }
          ]
        }
      }
    },
    {
      "name" : "aiDevice",
      "resource" : {
        "resourceType" : "Device",
        "id" : "RetinaAIDevice-input",
        "meta" : {
          "profile" : [
            "http://dips.no/fhir/RetinaIntegration/StructureDefinition/retina-ai-device"
          ]
        },
        "deviceName" : [
          {
            "name" : "AwesomeAI for Retina",
            "type" : "model-name"
          }
        ],
        "version" : [
          {
            "type" : {
              "coding" : [
                {
                  "code" : "model-number"
                }
              ]
            },
            "value" : "v2.1.0"
          },
          {
            "type" : {
              "coding" : [
                {
                  "code" : "software"
                }
              ]
            },
            "value" : "Standard protocol"
          }
        ]
      }
    },
    {
      "name" : "fullReport",
      "valueAttachment" : {
        "contentType" : "text/plain",
        "data" : "SGVsbG8sIEZISVIhIFRoaXMgZmlsZSBjb250YWlucyB0aGUgZnVsbCByZXBvcnQgb2YgdGhlIEFpIGFuYWx5c2lzLg==",
        "title" : "Full report"
      }
    },
    {
      "name" : "validation",
      "valueBoolean" : true
    }
  ]
}

```
