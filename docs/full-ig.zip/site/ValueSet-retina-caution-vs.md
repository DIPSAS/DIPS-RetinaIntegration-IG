# Retina Cautions - RetinaIntegration v0.6.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Retina Cautions**

## ValueSet: Retina Cautions 

| | |
| :--- | :--- |
| *Official URL*:http://dips.no/fhir/RetinaIntegration/ValueSet/retina-caution-vs | *Version*:0.6.0 |
| Draft as of 2025-12-07 | *Computable Name*:RetinaCautionValueSet |

 
Special considerations or cautions for grading this examination (5000-series). 

 **References** 

* [Cautions](StructureDefinition-cautions-extension.md)

### Logical Definition (CLD)

 

### Expansion

-------

 Explanation of the columns that may appear on this page: 

| | |
| :--- | :--- |
| Level | A few code lists that FHIR defines are hierarchical - each code is assigned a level. In this scheme, some codes are under other codes, and imply that the code they are under also applies |
| System | The source of the definition of the code (when the value set draws in codes defined elsewhere) |
| Code | The code (used as the code in the resource instance) |
| Display | The display (used in the*display*element of a[Coding](http://hl7.org/fhir/R4/datatypes.html#Coding)). If there is no display, implementers should not simply display the code, but map the concept into their application |
| Definition | An explanation of the meaning of the concept |
| Comments | Additional notes about how to use the code |



## Resource Content

```json
{
  "resourceType" : "ValueSet",
  "id" : "retina-caution-vs",
  "url" : "http://dips.no/fhir/RetinaIntegration/ValueSet/retina-caution-vs",
  "version" : "0.6.0",
  "name" : "RetinaCautionValueSet",
  "title" : "Retina Cautions",
  "status" : "draft",
  "experimental" : false,
  "date" : "2025-12-07",
  "publisher" : "DIPS AS",
  "contact" : [
    {
      "name" : "DIPS AS",
      "telecom" : [
        {
          "system" : "url",
          "value" : "http://dips.no/"
        },
        {
          "system" : "email",
          "value" : "teamsolsiden@dips.no"
        }
      ]
    }
  ],
  "description" : "Special considerations or cautions for grading this examination (5000-series).",
  "compose" : {
    "include" : [
      {
        "system" : "http://dips.no/fhir/RetinaIntegration/CodeSystem/retina-caution-cs"
      }
    ]
  }
}

```
